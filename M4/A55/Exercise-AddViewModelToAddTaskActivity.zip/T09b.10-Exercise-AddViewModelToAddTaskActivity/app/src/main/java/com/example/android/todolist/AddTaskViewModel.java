package com.example.android.todolist;

// TODO (5) Make this class extend ViewModel
public class AddTaskViewModel {

    // TODO (6) Add a task member variable for the TaskEntry object wrapped in a LiveData

    // TODO (8) Create a constructor where you call loadTaskById of the taskDao to initialize the tasks variable
    // Note: The constructor should receive the database and the taskId

    // TODO (7) Create a getter for the task variable
}
